# 🎲 Online Ludo Game

A fully functional online multiplayer Ludo game that allows friends and family to play together from anywhere in the world! Built with HTML, CSS, and JavaScript with real-time synchronization.

## 🌟 Features

### ✅ Currently Completed Features

#### Core Gameplay
- **Classic Ludo Rules**: Full implementation of traditional Ludo game mechanics
- **4 Player Support**: Supports 2-4 players with different color options (Red, Blue, Green, Yellow)
- **Token Movement**: Smooth token movement with visual feedback
- **Dice Rolling**: Animated dice with random number generation (1-6)
- **Capturing Mechanics**: Players can capture opponent tokens and send them back home
- **Safe Spots**: Protected positions where tokens cannot be captured (marked with ★)
- **Home Stretch**: Dedicated path leading to the center for each color
- **Win Detection**: Automatic detection when a player finishes all 4 tokens
- **Extra Turn Rules**: Players get extra turns on rolling 6 or capturing opponents

#### Multiplayer Features
- **Room System**: Create or join game rooms using 6-digit room codes
- **Real-time Sync**: Game state synchronizes every 2 seconds across all players
- **Room Codes**: Easy-to-share 6-digit codes for joining games
- **Player Management**: Host controls and player tracking
- **Turn-based Play**: Automatic turn management with visual indicators
- **Game Log**: Real-time activity feed showing all game events

#### User Interface
- **Modern Design**: Beautiful gradient backgrounds and smooth animations
- **Responsive Layout**: Works perfectly on desktop, tablet, and mobile devices
- **Color Selection**: Players can choose their preferred color when creating a game
- **Waiting Room**: Lobby system where players wait before game starts
- **Winner Screen**: Celebratory screen when a player wins
- **Toast Notifications**: Helpful feedback messages for user actions
- **Loading States**: Visual feedback during API operations

#### Technical Features
- **RESTful API Integration**: Uses Table API for data persistence
- **Session Management**: Proper game state management across sessions
- **Error Handling**: Graceful error handling with user-friendly messages
- **No Server Required**: Fully client-side implementation using static hosting

## 🎮 How to Play

### Starting a Game

1. **Create a Room**:
   - Enter your name
   - Select your preferred color (Red, Blue, Green, or Yellow)
   - Click "Create Game Room"
   - Share the 6-digit room code with friends

2. **Join a Room**:
   - Enter your name
   - Enter the 6-digit room code from your friend
   - Click "Join Game"
   - Wait for the host to start the game

### Game Rules

1. **Objective**: Be the first to move all 4 tokens from home to the center finish area

2. **Rolling the Dice**:
   - Click "Roll Dice" when it's your turn
   - You get a random number from 1-6

3. **Moving Tokens**:
   - **Starting**: Need to roll a 6 to bring a token out of home
   - **Movement**: Click on your token to move it by the dice value
   - **Capturing**: Land on an opponent's token (not on safe spots) to send it back home
   - **Safe Spots**: Marked with ★ - tokens here cannot be captured
   - **Finishing**: Must roll exact number to reach the center

4. **Special Rules**:
   - Roll a 6: Get an extra turn
   - Capture opponent: Get an extra turn
   - No valid moves: Turn automatically passes
   - Must reach center exactly: Can't overshoot

### Controls

- **Roll Dice Button**: Available during your turn
- **Token Click**: Click your tokens to move them (when moves are available)
- **Exit Game**: Leave the current game
- **Copy Code**: Copy room code to clipboard

## 📁 Project Structure

```
online-ludo-game/
├── index.html           # Main HTML file with game structure
├── css/
│   └── style.css       # Complete styling and animations
├── js/
│   ├── game-logic.js   # Core game rules and logic
│   └── main.js         # UI controller and multiplayer sync
└── README.md           # This file
```

## 🔧 Technical Details

### Technologies Used
- **HTML5**: Semantic structure with SVG for game board
- **CSS3**: Modern styling with animations and responsive design
- **JavaScript (ES6+)**: Game logic and API integration
- **Font Awesome**: Icons for UI elements
- **Google Fonts**: Poppins font family
- **RESTful Table API**: Data persistence and multiplayer sync

### Data Model

**Table: ludo_games**
- `id`: Unique game identifier
- `room_code`: 6-digit room code
- `game_state`: JSON string containing complete game state
- `players`: JSON array of player objects
- `current_turn`: Index of current player (0-3)
- `status`: Game status (waiting/playing/finished)
- `winner`: Winner's color or null
- `last_action`: Description of last game action

### Game State Structure
```javascript
{
  tokens: {
    red: [{ id, position, inHome, finished }, ...],
    blue: [...],
    green: [...],
    yellow: [...]
  },
  currentTurn: 0,
  diceValue: null,
  lastAction: "string",
  status: "playing",
  winner: null
}
```

## 🚀 API Endpoints

The game uses the following RESTful API endpoints:

- `GET tables/ludo_games?search={room_code}` - Find room by code
- `GET tables/ludo_games/{id}` - Get specific game state
- `POST tables/ludo_games` - Create new game room
- `PATCH tables/ludo_games/{id}` - Update game state
- `DELETE tables/ludo_games/{id}` - Delete game room

## 🎨 Features Highlights

### Visual Elements
- **Animated Dice**: Rolling animation with icon changes
- **Token Highlights**: Moveable tokens shake to indicate availability
- **Color-coded UI**: Each player has a distinct color theme
- **Turn Indicator**: Bouncing colored circle shows current player
- **Winner Animation**: Trophy animation on game completion

### Responsive Design
- Mobile-friendly layout (down to 320px width)
- Touch-optimized controls for mobile devices
- Flexible grid system for different screen sizes
- Adaptive font sizes and spacing

## 🔮 Features Not Yet Implemented

- **Private Rooms**: Password-protected game rooms
- **Game Chat**: In-game text chat between players
- **Sound Effects**: Dice roll, token move, and capture sounds
- **Game History**: Track past games and statistics
- **Player Profiles**: Save player names and preferences
- **Spectator Mode**: Allow others to watch ongoing games
- **Custom Rules**: Toggle different Ludo variants
- **Reconnection**: Automatic reconnection after disconnect
- **AI Players**: Computer-controlled opponents for solo play
- **Tournaments**: Multi-round competition mode

## 🛠️ Recommended Next Steps

1. **Add Sound Effects**: Enhance user experience with audio feedback
2. **Implement Chat System**: Allow players to communicate during game
3. **Add Game Statistics**: Track wins, losses, and game history
4. **Improve Board Graphics**: Add more visual polish and animations
5. **Add Tutorial Mode**: Interactive tutorial for new players
6. **Implement Emojis/Reactions**: Quick emotional responses during gameplay
7. **Add Time Limits**: Optional timer for turns to speed up games
8. **Create Leaderboard**: Global or friend-based rankings
9. **Add Avatars**: Let players choose profile pictures
10. **Mobile App Version**: Convert to PWA or native app

## 🎯 Entry Points & Routes

### Main Routes
- `/` or `index.html` - Main game interface (all screens)

### Game Flow
1. **Lobby Screen** (`#lobby-screen`) - Entry point for creating/joining games
2. **Waiting Room** (`#waiting-screen`) - Pre-game lobby with player list
3. **Game Screen** (`#game-screen`) - Main gameplay interface
4. **Winner Screen** (`#winner-screen`) - Victory celebration

### URL Parameters
Currently none - all navigation is handled via screen states. Future enhancement could add URL routing for direct room access.

## 💾 Data Storage

The game uses the RESTful Table API for persistent data storage:
- **Game Rooms**: Stored in `ludo_games` table
- **Real-time Sync**: Polling every 2 seconds
- **Automatic Cleanup**: Rooms deleted when all players leave
- **State Persistence**: Complete game state saved on every move

## 🎓 How It Works

### Multiplayer Synchronization
1. Players create or join rooms using API calls
2. Game state is stored in database
3. All clients poll the API every 2 seconds
4. Local UI updates based on server state
5. Player actions update server state
6. Other players receive updates on next poll

### Game Logic Flow
1. **Turn Start**: Current player can roll dice
2. **Dice Roll**: Random 1-6 generated
3. **Move Selection**: Click moveable token
4. **Validation**: Check if move is legal
5. **Execution**: Update token position
6. **Capture Check**: Check for opponent captures
7. **Win Check**: Check if all tokens finished
8. **Turn End**: Pass to next player (unless extra turn)

## 📱 Browser Compatibility

- ✅ Chrome/Edge (Recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Mobile Browsers (iOS Safari, Chrome Mobile)
- ⚠️ IE11 (Not supported - ES6 features used)

## 🐛 Known Issues & Limitations

- **No Persistence**: Refreshing the page disconnects from game
- **No Reconnect**: Players cannot rejoin after disconnection
- **Polling Delay**: 2-second delay between moves
- **No Validation**: Trusts client-side game logic
- **Room Codes**: Not guaranteed unique (random generation)

## 🏆 Credits

Created with ❤️ as a fun project to bring people together through gaming!

## 📄 License

This project is open source and available for personal and educational use.

---

**Enjoy playing Ludo with your friends and family! 🎲🎉**

For issues or suggestions, please feel free to contribute or report bugs.
