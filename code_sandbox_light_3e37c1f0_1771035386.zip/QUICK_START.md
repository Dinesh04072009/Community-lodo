# 🎯 Quick Start Guide - Online Ludo Game

## Getting Started in 3 Easy Steps

### For The Host (Person Creating the Game)

1. **Open the Game**
   - Go to the game website
   - You'll see the lobby screen

2. **Create a Room**
   - Type your name in "Enter your name"
   - Pick your favorite color (Red, Blue, Green, or Yellow)
   - Click "Create Game Room"
   - You'll see a 6-digit code (like "123456")

3. **Share & Play**
   - Copy the 6-digit room code
   - Share it with your friends (via WhatsApp, SMS, etc.)
   - Wait for friends to join (minimum 2 players)
   - Click "Start Game" when ready!

### For Players Joining

1. **Get the Code**
   - Ask your friend for the 6-digit room code

2. **Join the Room**
   - Open the game website
   - Type your name in "Enter your name"
   - Enter the 6-digit code
   - Click "Join Game"

3. **Wait & Play**
   - Wait for host to start the game
   - Enjoy!

## 🎮 How to Play - Simple Rules

### Goal
Move all 4 of your tokens from home to the center finish area before your opponents!

### Your Turn
1. **Roll the Dice** - Click "Roll Dice" button
2. **Move a Token** - Click on one of your colored tokens to move it
3. **Wait** - Other players take their turns

### Important Rules
- 🎲 Need a **6** to bring a token out of home
- 🎲 Roll a **6**? Get an extra turn!
- 💥 Land on an opponent? Send them back home AND get an extra turn!
- ⭐ **Star spots** are safe - can't be captured there
- 🏁 Must roll the **exact number** to finish

### Tips for Beginners
- ✅ Bring out multiple tokens early (don't wait!)
- ✅ Use star spots for safety
- ✅ Try to capture opponents when possible
- ✅ Focus on getting at least one token home first
- ✅ Plan ahead - sometimes it's better to move a different token

## 📱 Device Tips

### Mobile Users
- Game works great on phones and tablets
- Use portrait or landscape mode
- Tap tokens directly to move them

### Desktop Users  
- Click tokens with mouse
- Game board is larger and easier to see
- Better for detailed strategy

## ❓ Common Questions

**Q: How many players can play?**  
A: 2-4 players per game

**Q: Do we need accounts?**  
A: No! Just enter your name and play

**Q: What if I close the browser?**  
A: You'll be disconnected. Stay on the page during the game!

**Q: Can I play with people far away?**  
A: Yes! Anyone with internet can join using your room code

**Q: How long does a game take?**  
A: Usually 15-30 minutes depending on luck and strategy

**Q: What if someone leaves?**  
A: The game continues with remaining players

## 🆘 Troubleshooting

**Problem: "Room not found"**
- Double-check the 6-digit code
- Make sure the host created the room
- Ask host to share code again

**Problem: "Room is full"**  
- Game only supports 4 players
- Host needs to create a new room

**Problem: "Can't move any tokens"**
- This happens when you roll a number that doesn't work
- Your turn will pass automatically
- Try again next turn!

**Problem: Button not working**
- Make sure it's your turn (check the colored indicator)
- Roll the dice before moving tokens
- Refresh the page if issues persist

## 🎉 Have Fun!

Remember, Ludo is a game of luck AND strategy. Don't get frustrated if the dice aren't rolling your way - that's part of the fun! 

**Most importantly: Enjoy playing with friends and family!** 🎲❤️

---

Need more help? Check the full README.md for detailed information.
