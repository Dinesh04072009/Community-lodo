// Main Game Controller
// Handles UI, multiplayer, and game state synchronization

let game = new LudoGame();
let currentRoom = null;
let currentPlayer = null;
let gameState = null;
let syncInterval = null;

// DOM Elements
const lobbyScreen = document.getElementById('lobby-screen');
const waitingScreen = document.getElementById('waiting-screen');
const gameScreen = document.getElementById('game-screen');
const winnerScreen = document.getElementById('winner-screen');
const loadingOverlay = document.getElementById('loading-overlay');
const toast = document.getElementById('toast');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    showScreen('lobby');
});

// Event Listeners
function setupEventListeners() {
    // Color selection
    document.querySelectorAll('.color-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('selected'));
            e.currentTarget.classList.add('selected');
        });
    });
    
    // Select red by default
    document.querySelector('.color-btn[data-color="red"]').classList.add('selected');
    
    // Create game
    document.getElementById('create-game-btn').addEventListener('click', createGame);
    
    // Join game
    document.getElementById('join-game-btn').addEventListener('click', joinGame);
    
    // Copy room code
    document.getElementById('copy-code-btn').addEventListener('click', copyRoomCode);
    
    // Start game
    document.getElementById('start-game-btn').addEventListener('click', startGame);
    
    // Leave room
    document.getElementById('leave-room-btn').addEventListener('click', leaveRoom);
    
    // Exit game
    document.getElementById('exit-game-btn').addEventListener('click', exitGame);
    
    // Roll dice
    document.getElementById('roll-dice-btn').addEventListener('click', rollDice);
    
    // New game
    document.getElementById('new-game-btn').addEventListener('click', () => {
        showScreen('lobby');
        resetGame();
    });
}

// Screen Management
function showScreen(screen) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(`${screen}-screen`).classList.add('active');
}

function showLoading(show = true) {
    loadingOverlay.classList.toggle('active', show);
}

function showToast(message, type = 'info') {
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// API Functions
async function apiCall(endpoint, method = 'GET', body = null) {
    try {
        const options = {
            method,
            headers: { 'Content-Type': 'application/json' }
        };
        
        if (body) {
            options.body = JSON.stringify(body);
        }
        
        const response = await fetch(`tables/ludo_games${endpoint}`, options);
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        // DELETE returns 204 No Content
        if (response.status === 204) {
            return null;
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Generate 6-digit room code
function generateRoomCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Create Game Room
async function createGame() {
    const playerName = document.getElementById('player-name').value.trim();
    const selectedColor = document.querySelector('.color-btn.selected')?.dataset.color;
    
    if (!playerName) {
        showToast('Please enter your name', 'error');
        return;
    }
    
    if (!selectedColor) {
        showToast('Please select a color', 'error');
        return;
    }
    
    showLoading(true);
    
    try {
        const roomCode = generateRoomCode();
        const players = [{
            name: playerName,
            color: selectedColor,
            isHost: true
        }];
        
        const gameData = {
            room_code: roomCode,
            game_state: JSON.stringify({}),
            players: JSON.stringify(players),
            current_turn: 0,
            status: 'waiting',
            winner: null,
            last_action: 'Room created'
        };
        
        const result = await apiCall('', 'POST', gameData);
        
        currentRoom = result;
        currentPlayer = { name: playerName, color: selectedColor, isHost: true };
        
        showScreen('waiting');
        updateWaitingRoom();
        startSyncInterval();
        
        showToast('Room created successfully!', 'success');
    } catch (error) {
        showToast('Failed to create room. Please try again.', 'error');
        console.error(error);
    } finally {
        showLoading(false);
    }
}

// Join Game Room
async function joinGame() {
    const playerName = document.getElementById('join-name').value.trim();
    const roomCode = document.getElementById('room-code').value.trim();
    
    if (!playerName) {
        showToast('Please enter your name', 'error');
        return;
    }
    
    if (!roomCode || roomCode.length !== 6) {
        showToast('Please enter a valid 6-digit room code', 'error');
        return;
    }
    
    showLoading(true);
    
    try {
        // Find room by code
        const response = await apiCall(`?search=${roomCode}&limit=1`, 'GET');
        
        if (!response.data || response.data.length === 0) {
            showToast('Room not found', 'error');
            showLoading(false);
            return;
        }
        
        const room = response.data[0];
        
        if (room.status !== 'waiting') {
            showToast('Game already started', 'error');
            showLoading(false);
            return;
        }
        
        const players = JSON.parse(room.players);
        
        if (players.length >= 4) {
            showToast('Room is full', 'error');
            showLoading(false);
            return;
        }
        
        // Find available color
        const usedColors = players.map(p => p.color);
        const availableColors = game.colors.filter(c => !usedColors.includes(c));
        
        if (availableColors.length === 0) {
            showToast('No colors available', 'error');
            showLoading(false);
            return;
        }
        
        // Add player
        players.push({
            name: playerName,
            color: availableColors[0],
            isHost: false
        });
        
        // Update room
        await apiCall(`/${room.id}`, 'PATCH', {
            players: JSON.stringify(players),
            last_action: `${playerName} joined the game`
        });
        
        currentRoom = { ...room, players: JSON.stringify(players) };
        currentPlayer = { name: playerName, color: availableColors[0], isHost: false };
        
        showScreen('waiting');
        updateWaitingRoom();
        startSyncInterval();
        
        showToast('Joined successfully!', 'success');
    } catch (error) {
        showToast('Failed to join room. Please try again.', 'error');
        console.error(error);
    } finally {
        showLoading(false);
    }
}

// Update Waiting Room Display
function updateWaitingRoom() {
    if (!currentRoom) return;
    
    const players = JSON.parse(currentRoom.players);
    const roomCodeDisplay = document.getElementById('display-room-code');
    const playersList = document.getElementById('players-list');
    const playerCount = document.getElementById('player-count');
    const startBtn = document.getElementById('start-game-btn');
    
    roomCodeDisplay.textContent = currentRoom.room_code;
    playerCount.textContent = players.length;
    
    // Update players list
    playersList.innerHTML = '';
    players.forEach(player => {
        const card = document.createElement('div');
        card.className = 'player-card';
        card.innerHTML = `
            <div class="player-color-badge" style="background-color: ${game.colorHex[player.color]}"></div>
            <p>${player.name}</p>
            ${player.isHost ? '<small>👑 Host</small>' : ''}
        `;
        playersList.appendChild(card);
    });
    
    // Enable start button for host if 2+ players
    if (currentPlayer.isHost && players.length >= 2) {
        startBtn.disabled = false;
    } else {
        startBtn.disabled = true;
    }
}

// Copy Room Code
function copyRoomCode() {
    const code = document.getElementById('display-room-code').textContent;
    navigator.clipboard.writeText(code).then(() => {
        showToast('Room code copied!', 'success');
    });
}

// Start Game
async function startGame() {
    if (!currentPlayer.isHost) {
        showToast('Only host can start the game', 'error');
        return;
    }
    
    showLoading(true);
    
    try {
        const players = JSON.parse(currentRoom.players);
        const initialState = game.createInitialGameState(players);
        
        await apiCall(`/${currentRoom.id}`, 'PATCH', {
            game_state: JSON.stringify(initialState),
            status: 'playing',
            last_action: 'Game started!'
        });
        
        showToast('Game started!', 'success');
    } catch (error) {
        showToast('Failed to start game', 'error');
        console.error(error);
    } finally {
        showLoading(false);
    }
}

// Leave Room
async function leaveRoom() {
    if (confirm('Are you sure you want to leave?')) {
        stopSyncInterval();
        
        try {
            if (currentRoom && currentPlayer) {
                const players = JSON.parse(currentRoom.players);
                const updatedPlayers = players.filter(p => p.name !== currentPlayer.name);
                
                if (updatedPlayers.length === 0) {
                    // Delete room if empty
                    await apiCall(`/${currentRoom.id}`, 'DELETE');
                } else {
                    // Update room
                    await apiCall(`/${currentRoom.id}`, 'PATCH', {
                        players: JSON.stringify(updatedPlayers),
                        last_action: `${currentPlayer.name} left the game`
                    });
                }
            }
        } catch (error) {
            console.error('Error leaving room:', error);
        }
        
        resetGame();
        showScreen('lobby');
    }
}

// Exit Game
function exitGame() {
    if (confirm('Are you sure you want to exit the game?')) {
        leaveRoom();
    }
}

// Sync Game State
async function syncGameState() {
    if (!currentRoom) return;
    
    try {
        const response = await apiCall(`/${currentRoom.id}`, 'GET');
        currentRoom = response;
        
        if (response.status === 'waiting') {
            if (document.getElementById('waiting-screen').classList.contains('active')) {
                updateWaitingRoom();
            }
        } else if (response.status === 'playing') {
            if (!document.getElementById('game-screen').classList.contains('active')) {
                showScreen('game');
            }
            
            gameState = JSON.parse(response.game_state);
            updateGameUI();
        } else if (response.status === 'finished') {
            stopSyncInterval();
            showWinner(response.winner);
        }
    } catch (error) {
        console.error('Sync error:', error);
        // Room might have been deleted
        if (error.message.includes('404')) {
            showToast('Room no longer exists', 'error');
            resetGame();
            showScreen('lobby');
        }
    }
}

// Start/Stop Sync Interval
function startSyncInterval() {
    stopSyncInterval();
    syncInterval = setInterval(syncGameState, 2000); // Sync every 2 seconds
}

function stopSyncInterval() {
    if (syncInterval) {
        clearInterval(syncInterval);
        syncInterval = null;
    }
}

// Update Game UI
function updateGameUI() {
    if (!gameState || !currentRoom) return;
    
    const players = JSON.parse(currentRoom.players);
    const currentTurnPlayer = players[gameState.currentTurn];
    
    // Update header
    document.getElementById('game-room-code').textContent = currentRoom.room_code;
    document.getElementById('current-player-name').textContent = currentTurnPlayer.name;
    document.getElementById('turn-indicator').style.backgroundColor = game.colorHex[currentTurnPlayer.color];
    
    // Update players info
    updatePlayersInfo(players);
    
    // Update dice
    if (gameState.diceValue) {
        document.getElementById('dice-value').textContent = gameState.diceValue;
        document.getElementById('dice').innerHTML = `<i class="fas ${game.getDiceIcon(gameState.diceValue)}"></i>`;
    }
    
    // Enable roll button if it's player's turn
    const isMyTurn = currentTurnPlayer.name === currentPlayer.name;
    document.getElementById('roll-dice-btn').disabled = !isMyTurn || gameState.diceValue !== null;
    
    // Update game log
    if (gameState.lastAction) {
        addLogEntry(gameState.lastAction);
    }
    
    // Render tokens
    game.renderTokens(gameState, isMyTurn ? handleTokenClick : null);
}

// Update Players Info Sidebar
function updatePlayersInfo(players) {
    const container = document.getElementById('players-info');
    container.innerHTML = '';
    
    players.forEach((player, index) => {
        const isActive = index === gameState.currentTurn;
        const tokensFinished = gameState.tokens[player.color].filter(t => t.finished).length;
        
        const card = document.createElement('div');
        card.className = `player-info-card ${isActive ? 'active' : ''}`;
        card.innerHTML = `
            <div class="player-info-color" style="background-color: ${game.colorHex[player.color]}"></div>
            <div class="player-info-details">
                <p>${player.name}</p>
                <small>${tokensFinished}/4 finished</small>
            </div>
        `;
        container.appendChild(card);
    });
}

// Add Log Entry
function addLogEntry(message) {
    const log = document.getElementById('game-log');
    const entry = document.createElement('p');
    entry.className = 'log-entry';
    entry.textContent = message;
    log.insertBefore(entry, log.firstChild);
    
    // Keep only last 20 entries
    while (log.children.length > 20) {
        log.removeChild(log.lastChild);
    }
}

// Roll Dice
async function rollDice() {
    const btn = document.getElementById('roll-dice-btn');
    btn.disabled = true;
    
    // Animate dice
    const diceElement = document.getElementById('dice');
    diceElement.classList.add('rolling');
    
    // Roll animation
    let rolls = 0;
    const rollInterval = setInterval(() => {
        const randomValue = Math.floor(Math.random() * 6) + 1;
        diceElement.innerHTML = `<i class="fas ${game.getDiceIcon(randomValue)}"></i>`;
        rolls++;
        if (rolls > 6) {
            clearInterval(rollInterval);
            performRoll();
        }
    }, 100);
}

async function performRoll() {
    const diceValue = Math.floor(Math.random() * 6) + 1;
    const diceElement = document.getElementById('dice');
    
    diceElement.innerHTML = `<i class="fas ${game.getDiceIcon(diceValue)}"></i>`;
    diceElement.classList.remove('rolling');
    document.getElementById('dice-value').textContent = diceValue;
    
    gameState.diceValue = diceValue;
    
    // Check if player can move any token
    const players = JSON.parse(currentRoom.players);
    const currentTurnPlayer = players[gameState.currentTurn];
    const movableTokens = game.getMovableTokens(currentTurnPlayer.color, diceValue, gameState);
    
    if (movableTokens.length === 0) {
        // No moves available, pass turn
        gameState.lastAction = `${currentTurnPlayer.name} rolled ${diceValue} but cannot move`;
        gameState.diceValue = null;
        nextTurn();
        await updateGameStateInDB();
        showToast('No moves available. Turn passed.', 'info');
    } else {
        // Highlight movable tokens
        game.renderTokens(gameState, handleTokenClick);
        document.querySelectorAll('.token').forEach(token => {
            const color = token.dataset.color;
            const id = parseInt(token.dataset.id);
            if (color === currentTurnPlayer.color && movableTokens.some(t => t.id === id)) {
                token.classList.add('moveable');
            }
        });
        
        await updateGameStateInDB();
    }
}

// Handle Token Click
async function handleTokenClick(color, tokenId) {
    if (!gameState.diceValue) {
        showToast('Roll the dice first!', 'info');
        return;
    }
    
    const players = JSON.parse(currentRoom.players);
    const currentTurnPlayer = players[gameState.currentTurn];
    
    if (color !== currentTurnPlayer.color) {
        showToast('Not your token!', 'error');
        return;
    }
    
    // Try to move token
    const result = game.moveToken(color, tokenId, gameState.diceValue, gameState);
    
    if (!result.success) {
        showToast(result.message, 'error');
        return;
    }
    
    gameState = result.gameState;
    
    // Check if game is finished
    if (gameState.status === 'finished') {
        await updateGameStateInDB();
        return;
    }
    
    // Check if player gets extra turn
    const extraTurn = game.shouldGetExtraTurn(gameState.diceValue, result.captured !== null);
    
    gameState.diceValue = null;
    
    if (!extraTurn) {
        nextTurn();
    } else {
        gameState.lastAction += ' - Extra turn!';
    }
    
    await updateGameStateInDB();
    game.renderTokens(gameState, handleTokenClick);
}

// Next Turn
function nextTurn() {
    const players = JSON.parse(currentRoom.players);
    gameState.currentTurn = (gameState.currentTurn + 1) % players.length;
}

// Update Game State in Database
async function updateGameStateInDB() {
    try {
        await apiCall(`/${currentRoom.id}`, 'PATCH', {
            game_state: JSON.stringify(gameState),
            current_turn: gameState.currentTurn,
            status: gameState.status,
            winner: gameState.winner,
            last_action: gameState.lastAction
        });
    } catch (error) {
        console.error('Failed to update game state:', error);
        showToast('Connection error. Please refresh.', 'error');
    }
}

// Show Winner
function showWinner(winnerColor) {
    const players = JSON.parse(currentRoom.players);
    const winner = players.find(p => p.color === winnerColor);
    
    document.getElementById('winner-name').textContent = winner.name;
    document.getElementById('winner-name').style.color = game.colorHex[winnerColor];
    
    showScreen('winner');
}

// Reset Game
function resetGame() {
    currentRoom = null;
    currentPlayer = null;
    gameState = null;
    stopSyncInterval();
    
    // Clear inputs
    document.getElementById('player-name').value = '';
    document.getElementById('join-name').value = '';
    document.getElementById('room-code').value = '';
}
