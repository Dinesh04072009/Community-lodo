// Game Logic for Ludo
// This file handles all game rules, board state, and token movements

class LudoGame {
    constructor() {
        this.colors = ['red', 'green', 'yellow', 'blue'];
        this.colorHex = {
            red: '#e74c3c',
            green: '#2ecc71',
            yellow: '#f1c40f',
            blue: '#3498db'
        };
        
        // Board path configuration
        this.boardPaths = this.generateBoardPaths();
        this.safeSpots = [0, 8, 13, 21, 26, 34, 39, 47]; // Safe spots on the main path
        this.homePositions = {
            red: [[80, 80], [160, 80], [80, 160], [160, 160]],
            green: [[440, 80], [520, 80], [440, 160], [520, 160]],
            yellow: [[80, 440], [160, 440], [80, 520], [160, 520]],
            blue: [[440, 440], [520, 440], [440, 520], [520, 520]]
        };
        
        this.initializeBoard();
    }

    generateBoardPaths() {
        const paths = {
            red: [],
            green: [],
            yellow: [],
            blue: []
        };
        
        const mainPath = [];
        const cellSize = 40;
        
        // Generate main path coordinates (52 cells around the board)
        // Red starts at position 0 (left middle going up)
        // Green starts at position 13 (top middle going right)
        // Yellow starts at position 26 (right middle going down)
        // Blue starts at position 39 (bottom middle going left)
        
        // Left column (going up) - Red's starting area
        for (let i = 0; i < 6; i++) {
            mainPath.push([240, 360 - i * cellSize]);
        }
        
        // Top-left corner (going right)
        for (let i = 0; i < 2; i++) {
            mainPath.push([240 + i * cellSize, 120]);
        }
        
        // Top middle column (going up to Green's start)
        for (let i = 0; i < 2; i++) {
            mainPath.push([320, 120 - i * cellSize]);
        }
        mainPath.push([320, 40]); // Green's starting position
        
        // Top middle (continuing right)
        for (let i = 0; i < 2; i++) {
            mainPath.push([320 + i * cellSize, 40]);
        }
        
        // Top-right corner (going down)
        for (let i = 0; i < 2; i++) {
            mainPath.push([400, 40 + i * cellSize]);
        }
        
        // Right column (going down) - Yellow's starting area
        for (let i = 0; i < 6; i++) {
            mainPath.push([360, 120 + i * cellSize]);
        }
        
        // Right middle (continuing down)
        for (let i = 0; i < 2; i++) {
            mainPath.push([360 + i * cellSize, 360]);
        }
        
        // Right middle column (going down to Blue's start)
        for (let i = 0; i < 2; i++) {
            mainPath.push([480, 360 + i * cellSize]);
        }
        mainPath.push([560, 440]); // Blue's starting position (adjusted)
        
        // Bottom middle (going left)
        for (let i = 0; i < 2; i++) {
            mainPath.push([560 - i * cellSize, 440]);
        }
        
        // Bottom-right corner (going left)
        for (let i = 0; i < 2; i++) {
            mainPath.push([480 - i * cellSize, 480]);
        }
        
        // Bottom column (going up) - Blue's path
        for (let i = 0; i < 6; i++) {
            mainPath.push([360, 480 - i * cellSize]);
        }
        
        // Bottom-left corner (going left)
        for (let i = 0; i < 2; i++) {
            mainPath.push([280 - i * cellSize, 360]);
        }
        
        // Left middle column (going up to Red's start)
        for (let i = 0; i < 2; i++) {
            mainPath.push([200, 360 - i * cellSize]);
        }
        
        // Home stretch paths (5 cells leading to center)
        const homeStretch = {
            red: [[280, 280], [280, 260], [280, 240], [280, 220], [280, 200]],
            green: [[320, 280], [340, 280], [360, 280], [380, 280], [400, 280]],
            yellow: [[320, 320], [320, 340], [320, 360], [320, 380], [320, 400]],
            blue: [[280, 320], [260, 320], [240, 320], [220, 320], [200, 320]]
        };
        
        // Build each color's complete path
        const startPositions = { red: 0, green: 13, yellow: 26, blue: 39 };
        
        for (let color of this.colors) {
            const start = startPositions[color];
            // Add main path from starting position
            for (let i = 0; i < 51; i++) {
                const index = (start + i) % 52;
                if (index < mainPath.length) {
                    paths[color].push(mainPath[index]);
                }
            }
            // Add home stretch
            paths[color] = paths[color].concat(homeStretch[color]);
        }
        
        return paths;
    }

    initializeBoard() {
        this.drawBoardPaths();
    }

    drawBoardPaths() {
        const svg = document.getElementById('board-paths');
        if (!svg) return;
        
        svg.innerHTML = '';
        
        // Draw all path cells
        const colors = ['red', 'green', 'yellow', 'blue'];
        const startPositions = { red: 0, green: 13, yellow: 26, blue: 39 };
        
        // Draw main path (52 cells)
        for (let i = 0; i < 52; i++) {
            let cellColor = '#fff';
            let isStartSpot = false;
            let isSafe = this.safeSpots.includes(i);
            
            // Check if it's a starting spot for any color
            for (let color of colors) {
                if (startPositions[color] === i) {
                    cellColor = this.colorHex[color];
                    isStartSpot = true;
                    break;
                }
            }
            
            // Get position from red's path (since it starts at 0)
            const pos = this.boardPaths.red[i];
            if (!pos) continue;
            
            const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            rect.setAttribute('x', pos[0] - 18);
            rect.setAttribute('y', pos[1] - 18);
            rect.setAttribute('width', 36);
            rect.setAttribute('height', 36);
            rect.setAttribute('fill', cellColor);
            rect.setAttribute('stroke', '#333');
            rect.setAttribute('stroke-width', '2');
            rect.setAttribute('rx', '4');
            
            if (isSafe && !isStartSpot) {
                rect.setAttribute('stroke', '#f39c12');
                rect.setAttribute('stroke-width', '3');
            }
            
            svg.appendChild(rect);
            
            // Add star for safe spots
            if (isSafe && !isStartSpot) {
                const star = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                star.setAttribute('x', pos[0]);
                star.setAttribute('y', pos[1] + 6);
                star.setAttribute('text-anchor', 'middle');
                star.setAttribute('font-size', '20');
                star.setAttribute('fill', '#f39c12');
                star.textContent = '★';
                svg.appendChild(star);
            }
        }
        
        // Draw home stretch paths for each color
        for (let color of colors) {
            const homeStretch = this.boardPaths[color].slice(51, 56);
            homeStretch.forEach((pos, index) => {
                const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                rect.setAttribute('x', pos[0] - 18);
                rect.setAttribute('y', pos[1] - 18);
                rect.setAttribute('width', 36);
                rect.setAttribute('height', 36);
                rect.setAttribute('fill', this.colorHex[color]);
                rect.setAttribute('opacity', 0.3 + (index * 0.1));
                rect.setAttribute('stroke', '#333');
                rect.setAttribute('stroke-width', '2');
                rect.setAttribute('rx', '4');
                svg.appendChild(rect);
            });
        }
    }

    createInitialGameState(players) {
        const state = {
            tokens: {},
            currentTurn: 0,
            diceValue: null,
            lastAction: 'Game started!',
            status: 'playing',
            winner: null
        };

        // Initialize tokens for each player
        players.forEach((player, index) => {
            const color = player.color;
            state.tokens[color] = [
                { id: 0, position: -1, inHome: true, finished: false },
                { id: 1, position: -1, inHome: true, finished: false },
                { id: 2, position: -1, inHome: true, finished: false },
                { id: 3, position: -1, inHome: true, finished: false }
            ];
        });

        return state;
    }

    canMoveToken(token, diceValue, color, gameState) {
        // Can't move if no dice value
        if (!diceValue) return false;
        
        // Can't move finished tokens
        if (token.finished) return false;
        
        // Token in home - needs 6 to come out
        if (token.inHome) {
            return diceValue === 6;
        }
        
        // Check if move would exceed board length
        const newPosition = token.position + diceValue;
        const maxPosition = 56; // 51 main path + 5 home stretch
        
        if (newPosition >= maxPosition) {
            // Can only finish if exact
            return newPosition === maxPosition;
        }
        
        return true;
    }

    getMovableTokens(color, diceValue, gameState) {
        const tokens = gameState.tokens[color];
        return tokens.filter(token => this.canMoveToken(token, diceValue, color, gameState));
    }

    moveToken(color, tokenId, diceValue, gameState) {
        const token = gameState.tokens[color][tokenId];
        
        if (!this.canMoveToken(token, diceValue, color, gameState)) {
            return { success: false, message: 'Invalid move!' };
        }
        
        let captured = null;
        
        // Moving out of home
        if (token.inHome) {
            token.inHome = false;
            token.position = 0;
            gameState.lastAction = `${color} brought out a token!`;
        } else {
            // Normal move
            const newPosition = token.position + diceValue;
            
            // Check if reaching home
            if (newPosition >= 56) {
                if (newPosition === 56) {
                    token.finished = true;
                    token.position = 56;
                    gameState.lastAction = `${color} finished a token!`;
                    
                    // Check if player won
                    const allFinished = gameState.tokens[color].every(t => t.finished);
                    if (allFinished) {
                        gameState.status = 'finished';
                        gameState.winner = color;
                        gameState.lastAction = `${color} wins the game!`;
                    }
                } else {
                    return { success: false, message: 'Must roll exact number to finish!' };
                }
            } else {
                token.position = newPosition;
                
                // Check for captures (only on main path, not home stretch)
                if (newPosition < 51) {
                    captured = this.checkCapture(color, newPosition, gameState);
                }
                
                if (captured) {
                    gameState.lastAction = `${color} captured ${captured.color}'s token!`;
                } else {
                    gameState.lastAction = `${color} moved ${diceValue} steps`;
                }
            }
        }
        
        return { success: true, captured, gameState };
    }

    checkCapture(movingColor, position, gameState) {
        // Can't capture on safe spots
        if (this.safeSpots.includes(position)) {
            return null;
        }
        
        // Check each other color's tokens
        for (let color in gameState.tokens) {
            if (color === movingColor) continue;
            
            for (let token of gameState.tokens[color]) {
                // Skip tokens in home or finished
                if (token.inHome || token.finished) continue;
                
                // Check if on same position
                if (token.position === position) {
                    // Send token back to home
                    token.position = -1;
                    token.inHome = true;
                    return { color, tokenId: token.id };
                }
            }
        }
        
        return null;
    }

    shouldGetExtraTurn(diceValue, moveSuccessful) {
        // Get extra turn on rolling 6 or capturing
        return diceValue === 6 || moveSuccessful;
    }

    getTokenPosition(color, tokenId, gameState) {
        const token = gameState.tokens[color][tokenId];
        
        if (token.inHome) {
            return this.homePositions[color][tokenId];
        }
        
        if (token.finished) {
            return [300, 300]; // Center position
        }
        
        return this.boardPaths[color][token.position];
    }

    renderTokens(gameState, onTokenClick) {
        const svg = document.getElementById('tokens-layer');
        if (!svg) return;
        
        svg.innerHTML = '';
        
        for (let color in gameState.tokens) {
            gameState.tokens[color].forEach((token, index) => {
                const pos = this.getTokenPosition(color, index, gameState);
                if (!pos) return;
                
                // Create token group
                const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
                g.setAttribute('class', 'token');
                g.setAttribute('data-color', color);
                g.setAttribute('data-id', index);
                g.style.cursor = 'pointer';
                
                // Token circle
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', pos[0]);
                circle.setAttribute('cy', pos[1]);
                circle.setAttribute('r', token.finished ? 8 : 12);
                circle.setAttribute('fill', this.colorHex[color]);
                circle.setAttribute('stroke', '#fff');
                circle.setAttribute('stroke-width', '3');
                
                g.appendChild(circle);
                
                // Add click handler
                if (onTokenClick) {
                    g.addEventListener('click', () => onTokenClick(color, index));
                }
                
                svg.appendChild(g);
            });
        }
    }

    getDiceIcon(value) {
        const icons = {
            1: 'fa-dice-one',
            2: 'fa-dice-two',
            3: 'fa-dice-three',
            4: 'fa-dice-four',
            5: 'fa-dice-five',
            6: 'fa-dice-six'
        };
        return icons[value] || 'fa-dice';
    }
}

// Export for use in main.js
window.LudoGame = LudoGame;
